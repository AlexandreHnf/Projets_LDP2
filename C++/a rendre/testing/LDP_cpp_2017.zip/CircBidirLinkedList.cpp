#include <iostream>
#include <string>

#include "CircBidirLinkedList.hpp"

//liste circulaire doublement liée

// List::List(): _head(nullptr)         //Constructeur de Liste
// {

// }

// List::~List() //destructeur par défaut
// {

// }
